ELIXIR SPELLS - A utility for the Elixir card game by Mayfair Games
                                        (c) 2001 Arthur J. Dahm III
-------------------------------------------------------------------
palm@dahm.com - http://palm.dahm.com

This program is distributed as free software WITHOUT ANY WARRANTY;
without even the implied warranty of MERCHANTABILITY or FITNESS FOR
A PARTICULAR PURPOSE.


ABOUT ELIXIR SPELLS
===================
Elixir Spells is a helper utility for the Elixir card game by Mayfair
Games. Use it to keep track of uncast spells and their ingredients.


WHAT IS THE ELIXIR CARD GAME?
=============================
Each year, the most powerful wizards of the fairy realm participate
in a friendly and prankful magical joust. Only one can be the winner,
as each wizard competes to be the first to cast upon his opponents
spells from his list of hilarious spells, while searching for and
utilizing the strangest and most wonderful of spell components. Are
you ready to compete with these masters of magical might? Will the
powers of the cosmos lead you to victory, or will someone else claim
the prize? This game utilizes a two deck system, one of spells and
one of "finds". "Finds" are composed of components, magic items,
transactions and items. Spells requiring between 1 and 4 components
to cast, the first player to cast all his spells wins.  Elixir is a
humorous and fantastically fun card game great for the whole family.
A great beer and pretzel game, fast, furious, and fun. Simply perfect
for 3 to 8 players (human or not!), from 10 to 1000 years old!
Playing time 30-45 minutes.

Game by Los Rodriguez and Fr�d�ric Leygonie
Art by Bernard Bittler
Elixir is a magical card game published by Mayfair Games under license
from Asmod�e �ditions and Week End Games
www.coolgames.com


USING ELIXIR SPELLS
===================
While choosing your spells in the Elixir card game, tap "Add Spells..."
to add spells to your list of uncast spells by checking the checkbox
next to the appropriate spell names. The spells you check off should
coincide with the spell cards that are face down in front of you. Tap
"Done" to return to the list of uncast spells. The drop down menu can
be used to deselect all checked spells.

During the game, tap "Cast" to cast a spell and remove it from your list
of uncast spells. Tap the note icon next to a spell's name to read the
description of that spell. Tap the "Ingredients..." button to see a list
of all the ingredients needed for all your uncast spells.

From the list of uncast spells, the drop down menu can be used to set
the preferences to show a spell's description when it is cast. The drop
down menu can also be used to cast all spells, preparing Elixir Spells
for a new game of Elixir.


SYSTEM REQUIREMENTS
===================
Elixir Spells requires a Palm device running Palm OS 3.0 or higher.


INSTALLATION
============
HotSync the elixir.prc file to your Palm OS handheld.


HISTORY
=======
Version 1.0 - initial release

Version 1.1 - fixed typos in spell descriptions
            - tapping on the spell name in the "Add Spells.." spell list
              will bring up the spell description
            - holding the pen on an ingredient will display the
              ingredient's name at the bottom of the screen

Version 1.1.1 - fixed ingredient name obscuring up/down buttons in
                ingredients needed form
              - fixed cast all not resetting spell points to 0 in uncast
                spells form

Version 1.2 - Made "Play during your turn" and "Play at any time" text
              color red in spell descriptions
            - Updated About screen
            - Added Donate screen

Version 1.2a - Fixed background of 2 bit icon

