
GIRL GENIUS MESSAGE DECODER             (c) 2002 Arthur J. Dahm III
                                                      palm@dahm.com
                                                      palm.dahm.com
-------------------------------------------------------------------


This program is distributed as free software WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

Girl Genius, The Secret Cypher Society Decoder, Agatha Heterodyne and all Girl Genius art, characters, design elements and logos TM & �2001 Studio Foglio. Art by Phil & Kaja Foglio, www.studiofoglio.com, is used with permission.


ABOUT GIRL GENIUS MESSAGE DECODER
=================================
Girl Genius Message Decoder decodes secret messages found in the back of each issue of Studio Foglio's (www.studiofoglio.com) Girl Genius comic book series.


USING GIRL GENIUS MESSAGE DECODER
=================================
Enter the five characters in the key box using the on-screen keyboard or Graffiti input.  The little arrow below the rollers moves to the right as each character is typed.

After entering the key, enter the encoded message.  The decoded message appears on the topmost set of rollers.  The set of rollers below the decoded message will help you keep track of your position within the encoded message by showing the encoded message as you type it.  The roller to the right of the key shows each character as it is decoded.  It is useful for reading secret messages embedded within the main secret message.

Tap the reset button to decode a new message.  It clears all the rollers and resets the pointer to the beginning.

There are several advanced options available by tapping the menu button:

"View Message..." - View the entire decoded message in a dialog box.

"ASCII/Symbol Table..." - Shows the ASCII equivalents of the special decoder symbols.  The ASCII equivalents can be used when entering characters using Graffiti input or when emailing messages to friends.

"Preferences..." - Turns all animation on or off.  Turning off animation speeds up the decoding process.


SYSTEM REQUIREMENTS
===================
Girl Genius Message Decoder requires a Palm device running Palm OS 3.1 or higher.


INSTALLATION
============
HotSync the decoder.prc file to your Palm OS handheld.


HISTORY
=======
Version 1.0 - initial release

