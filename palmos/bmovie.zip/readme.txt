B-Movie Titles
Version 1.1
� 2002 Arthur J. Dahm III
All rights reserved

http://palm.dahm.com
palm@dahm.com

Become the next Ed Wood and create your own B-Movie titles (Angora sweaters not included).

Tap the words to create yor movie title.
Tap 'More' if you need more words.
Tap 'Clear' to erase the movie title.
Tap 'Reset' to get more words and erase the movie title.

Visit palm.dahm.com for more freeware and shareware applications for Palm OS devices.

Version History
1.0 - Release version
1.1 - Fixed "An" button
