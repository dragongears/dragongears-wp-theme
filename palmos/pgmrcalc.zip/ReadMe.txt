
PGMRCALC                           (c) 2002-2009 Arthur J. Dahm III
                                              E-mail: palm@dahm.com
                                                 Web: palm.dahm.com
-------------------------------------------------------------------


ABOUT PGMRCALC
==============
PgmrCalc is a replacement for the included Palm OS calculator for
programmers.  It supports hexadecimal, decimal, octal and binary
number bases and can perform boolean operations.

A Windows version of PgrmCalc with similar functionality is also
available at palm.dahm.com


USING PGMRCALC
==============
If you're a programmer and you don't know how to use a calculator,
you're in trouble. :-) 


SYSTEM REQUIREMENTS
===================
PgmrCalc requires a Palm OS handheld device or smartphone running
Palm OS 3.1 or higher. Supported devices include Treo and Centro
phones.


INSTALLATION
============
Use the Palm HotSync manager to install either prgmrcalc.prc or
pgmrcalc_lite.prc to your Palm OS handheld.


DONATE
======
PgmrCalc is free to use. However, if you find it useful please
consider making a donation to show your support.

Any amount is greatly appreciated.

The best way to send a donation is by sending a PayPal (www.paypal.com)
payment to palm@dahm.com. PayPal is free and easy to use.

Thanks,
Art


HISTORY
=======
Version 1.0
 - initial release

Version 1.1
 - Redesigned B&W calculator keys to increase contrast between
   pressed and non-pressed states
 - Fixed subtraction always returns 0

Version 1.2
 - Added support for Handspring Treo keyboard
 - Added Keyboard/Graffiti Help Form
 - Changed from Freeware to Shareware

Version 1.3
 - Added version with hi-res graphics for 320x320 displays
 - Added more memory registers (6 total)
 - Added menu option to display all memory registers
 - Updated calculator key graphics on color devices
 - Updated icon graphics
 - Added visual feedback on onscreen keyboard when using graffiti
   or keyboard
 - Reconfigured Keyboard/Graffiti keypad equivalents
 - Added Treo 600 navigation to dialogs
 - Reformatted Keyboard/Graffiti help screen
 - Fixed "Error" not being completely erased from display

